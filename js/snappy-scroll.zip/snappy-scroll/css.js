// Create and add a <style> tag with all the CSS used by this library
(function applyCSS() {
  const css = `html {
    overflow: hidden;
    scroll-behavior: smooth;
    scroll-snap-type: y proximity;
  }

  .universe-bg {
    background-color: rgb(48, 48, 48);
  }

  .universe {
    min-width: 100%;
    margin: 0 auto;
    display: flex;
  }

  section {
    background-color: #ecf0f1;
    overflow-x: hidden;
    width: 100%;
    height: 100vh;
    scroll-snap-align: center;
    -webkit-box-shadow: inset 0px 0px 5px 0px rgba(51,51,51,0.75);
    -moz-box-shadow: inset 0px 0px 5px 0px rgba(51,51,51,0.75);
    box-shadow: inset 0px 0px 5px 0px rgba(51,51,51,0.75);
  }

  /* a shadow class for anything that wants it */
  .shadow {
    -webkit-box-shadow: 0px 0px 20px 0px rgba(51,51,51,0.75);
    -moz-box-shadow: 0px 0px 20px 0px rgba(51,51,51,0.75);
    box-shadow: 0px 0px 20px 0px rgba(51,51,51,0.75);
  }

  .topShadow {
    -webkit-box-shadow: 0px -20px 20px 0px rgba(51,51,51,0.75);
    -moz-box-shadow: 0px -20px 20px 0px rgba(51,51,51,0.75);
    box-shadow: 0px -20px 20px 0px rgba(51,51,51,0.75);
  }

  /* a fade class for anything that wants it */
  .fade {
    animation: fade-animate 2s infinite;
    -webkit-animation: fade-animate 2s infinite;
    -moz-animation: fade-animate 2s infinite; 
  }
  
  @keyframes fade-animate{
    0% {opacity:0}
    40% {opacity:1}
    80% {opacity:0}
    100% {opacity:0}
  }
  @-webkit-keyframes fade-animate{
    0% {opacity:0}
    40% {opacity:1}
    80% {opacity:0}
    100% {opacity:0}
  }
  @-moz-keyframes fade-animate{
    0% {opacity:0}
    40% {opacity:1}
    80% {opacity:0}
    100% {opacity:0}
    }

  .navIcon {
    border: 2px solid #A7A7A732;
    color: #A7A7A7;
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    justify-content: center;
    align-items: center;
    margin: 2px;
    height: 60px;
    width: 200px;
    -webkit-box-shadow: 5px 0px 5px 0px rgba(0,0,0,1);
    -moz-box-shadow: 5px 0px 5px 0px rgba(0,0,0,1);
    box-shadow: 5px 0px 5px 0px rgba(0,0,0,1);
    transition: all 0.25s ease;
  }
  
  .navIcon-highlight {
    color: #ffffff;
    transform: translateX(20px);
    cursor: pointer;
  }
  
  .nav-icon-label {
    text-transform: uppercase;
  }

  .nav-icon-desc {
    font-size: 0.5em;
    color: rgb(127,127,127);
  }
  
  .svgIcon {
    position: fixed;
    z-index: 2;
    width: 32px;
    height: 32px;
    -webkit-box-shadow: 0px 0px 2px 0px rgba(51,51,51,0.75);
    -moz-box-shadow: 0px 0px 2px 0px rgba(51,51,51,0.75);
    box-shadow: 0px 0px 2px 0px rgba(51,51,51,0.75);
    /* transition: all 0.6s ease; */
  }

  .svgIconPath {
    stroke-width: 1px;
    stroke: #A7A7A7;
    opacity: 0.75;
    fill: #555555;
  }

  .svgIconPath-highlight {
    fill: #ffffff;
  }
  
  .sideNavButton {
    border-top-left-radius: 0px;
    border-bottom-left-radius: 0px;
    position: fixed;
    /* margin-left: -4px; */
    top:1vh;
  }

  .scrollArrowUp {
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  
  .scrollArrowDown {
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
  }}`;

  const head = document.getElementsByTagName('head')[0];
  const style = document.createElement('style');
  style.type = 'text/css';
  style.appendChild(document.createTextNode(css));
  head.appendChild(style);
})();