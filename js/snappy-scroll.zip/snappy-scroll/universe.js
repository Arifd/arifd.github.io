// This creates an outer fullscreen container called universe with two columns inside
// The left for the navigation panel, and the right the <body> content
// when the navbar opens, it's actually the universe that is opening the left column,

import scroll from './scroll-mechanics.js';
import navbar from './side-nav-bar.js';

class Universe {
  constructor() {
    this.container = document.createElement('div');
    this.navCol = document.createElement('div');
    this.mainCol = document.createElement('div');

    // Main content goes inside a container so that it when pushed off screen it doesn't create overflow. (overflow:hidden; doesn't seem to have an effect here)
    this.mainContainer = document.createElement('div');

    this.init();
    this.genMainContent();
    this.append();
  }

  init() {
    this.container.setAttribute('class', 'universe-bg universe');
    
    this.navCol.style.cssText = 'min-width:0px;max-width:0px;height:100vh;transition:all 0.5s ease;';
    
    this.mainCol.setAttribute('class', 'universe-bg');
    this.mainCol.style.cssText = 'overflow-x:hidden;z-index:1;flex-grow:1;height:100%;transition:all 0.5 ease;box-shadow:0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)';
    
    this.mainContainer.style.cssText = 'min-width:100vw;transition:all 0.5s ease;';
  }

  genMainContent() {
    // (Perhaps we should steal everything inside <body>, not only <section>?)
    this.mainContainer.append(...scroll.sections);
  }

  append() {
    this.navCol.appendChild(navbar.container);
    this.container.appendChild(this.navCol);
    
    this.mainCol.append(this.mainContainer);
    this.container.appendChild(this.mainCol);
    
    document.body.append(this.container);
  }
}

const universe = new Universe();
console.log(universe);
export default universe;