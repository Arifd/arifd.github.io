/** 
  * snappy-scroll.js
  * ----------------
  *  
  * This library adds:
  * - scroll snapping to <section> and makes every <section> full screen
  * - keyboard, wheel and button precision navigation, no more scrolling! 
  * - scroll indicators which are also navigation buttons
  * - auto generated side-navbar
  * - beautiful and elegant scrolling transitions
  * 
  * - credit:
  * - svg icons: https://git.blivesta.com/flexicon/
  * 
  * @author Arif Driessen
  */

import './css.js';
import './universe.js'; // loads mechanics and navbar
import './input.js';
import './scroll-indicators.js';

// Hacks
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Mobile browsers ignore the address bar in vh calculation.
// To get around this we manually calculate it on every resize
// function mobileFullScreen() {
//   const height = `${window.innerHeight}px`;
//   navCol.style.height = height;
//   for (let e of ELEMENTS) e.style.height = height; // prefer mainContent height?
// }
// window.addEventListener('load', mobileFullScreen); 
// window.addEventListener('resize', mobileFullScreen);