// This is where sections, visibilities and location is stored.

const clamp = (val, min, max) => Math.min(Math.max(min, val), max);

class ScrollMechanics {
  constructor() {
    this.sections = document.getElementsByTagName('section');
    this.visibilities = new Array(this.sections.length).fill(0); // normalized visibilty of each <section>
    this.location = 0; // Stores the index of which <section> has most viewport focus

    window.addEventListener('scroll', () => this.update());
  }

  // This function should be used for all website navigation
  navigate(to) {
    // is 'to' a relative number or absolute location string?
    if (typeof to === 'string') { // is absolute
      window.location.href = '#' + to;
    } else { // is number
      // to: -1: previous, 1: next
      // find out where you are, then navigate to next/previous element
      const destination = clamp(this.location + to, 0, this.sections.length-1);
      window.location.href = `#${this.sections[destination].id}`;
    }
    // trigger animation
    // transitionElementsOnNavigate(destination);
    // transitionElementContentOnNavigate(destination);
  }

  update() {
    this.updateVisibilities();
    this.location = this.mostVisibleElementIndex();
    this.transitionSectionsOnScroll();
  }
  
  updateVisibilities() {
    // Get visibility percentages for each <section>
    // index represents <section> order
    for (let i = 0; i < this.visibilities.length; i++) {
      this.visibilities[i] = this.getPercentVisible(this.sections[i]);
    }
  }
  
  mostVisibleElementIndex() {
    let index = 0;
    this.visibilities.reduce((prev, curr, i) => {
      const mostVisible = Math.max(prev, curr);
      if (mostVisible === curr) index = i;
      return mostVisible;
    }, 0);
    return index;
  }
  
  getPercentVisible(element) {
    const rect = element.getBoundingClientRect();
    
    // If not even partially visible, return early
    if (rect.top >= window.innerHeight || rect.bottom <= 0) return 0;
    
    const topIsVisible = rect.top >= 0 && rect.top < window.innerHeight;
    const bottomIsVisible = rect.bottom < window.innerHeight && rect.bottom >= 0;
    
    const topCheck = function() {
      const pixelsVisible = window.innerHeight - rect.top;
      // const negativeSpace = window.innerHeight - negativeSpace;
      const percentVisible = pixelsVisible / rect.height;
      return percentVisible;
    }
    
    const bottomCheck = function() {
      const negativeSpace = window.innerHeight - rect.bottom;
      const pixelsVisible = clamp(window.innerHeight - negativeSpace, 0, rect.height);
      const percentVisible = pixelsVisible / rect.height;
      return percentVisible;
    }
    
    if (topIsVisible && bottomIsVisible) return 1;
    else if (topIsVisible) return topCheck();
    else if (bottomIsVisible) return bottomCheck();
    else return -1; // something went wrong!
  }

  // add a fading aesthetic to the scrolling.
  transitionSectionsOnScroll() {
    // fade in and out on scroll
    for (let i = 0; i < this.sections.length; i++) {
      this.sections[i].style.transition = 'opacity 0.1s ease';
      this.sections[i].style.opacity = this.visibilities[i];
      // this.sections[i].style.transform = `scale(${(1 - this.visibilities[i]) * window.innerWidth}px)`;
      
      // animate the content INSIDE the sections
      if (this.visibilities[i] === 1)
      for (let e of this.sections[i].children) {
        // fade out
        e.style.opacity = 1;
        e.style.transition = 'all 0.6s cubic-bezier(0,1,1,1)';
        e.style.transform = 'translateX(0px)';
      }
      if (this.visibilities[i] <= 0.1)
        for (let e of this.sections[i].children) {
          // fade in
          e.style.opacity = 0;
          e.style.transition = 'all 0s';
          e.style.transform = `translateX(20px)`;
        }
    }
  }
}

const scrollMechanics = new ScrollMechanics();
console.log(scrollMechanics);
export default scrollMechanics;